@echo off
setlocal
cd /d "%~dp0"
"%~dp0runtime\python.exe" -E -s "%~dp0app\baslat.py"
if errorlevel 1 (
 echo Program acilamadi. Yukaridaki hata mesajini kontrol edin.
 pause
)
