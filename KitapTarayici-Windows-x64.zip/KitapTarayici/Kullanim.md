# Kitap Tarayıcı

Windows 10/11 (64 bit) için yerel masaüstü uygulaması. E-kitabın ekranda görünen alanını yakalar, seçtiğiniz **sonraki sayfa düğmesine tıklar** ve sayfaları PDF ile Word belgesine dönüştürür. İnternet üzerinden görüntü veya metin göndermez.

## Kullanım

**Taşınabilir paket:** `KitapTarayici-Windows-x64.zip` dosyasını tamamen bir klasöre çıkarın ve içindeki **Baslat.bat** dosyasını çift tıklayın. Python ve uygulama bağımlılıkları paketin içindedir; PDF ve görüntülü Word için kurulum veya internet gerekmez. ZIP içinden doğrudan çalıştırmayın.

1. E-kitabınızı Windows'un **ana ekranında** açın. Pencere boyutunu, yakınlaştırmayı ve ilk sayfayı ayarlayın.
2. **Sayfa alanını seç** düğmesine basın; kitabın sayfasını çevreleyen dikdörtgeni fareyle sürükleyin. Sayaç, gezinme düğmesi ve araç çubuklarını alanın dışında tutun.
3. **Sonraki sayfa düğmesini seç** düğmesine basın ve okuyucunuzdaki düğmenin ortasına tıklayın. İsterseniz geçiş türünü sağ ok veya Page Down olarak değiştirebilirsiniz.
4. Kitap adını, yakalanacak en fazla sayfa sayısını, sayfa bekleme süresini ve çıktı klasörünü ayarlayın. Varsayılan çıktı **PDF + görüntülü Word**.
5. **Taramayı başlat** düğmesine basın. Uygulama küçülür. Başlangıç sayacı dolmadan e-kitap penceresini öne getirin. Açık ilk sayfa da kaydedilir.
6. Tarama sırasında fareyi/klavyeyi kullanmayın, pencereleri taşımayın ve ekranı kilitlemeyin. **Esc** veya uygulamadaki **Durdur** düğmesi taramayı durdurur; o ana kadar yakalanmış sayfalar PDF ve Word'e aktarılır. Dışa aktarma sırasında yeniden Esc, Word aktarımını durdurur; PDF ve PNG'ler korunur.
7. **Çıktı klasörünü aç** düğmesiyle dosyalara ulaşın.

Her tarama ayrı bir zaman damgalı klasöre yazılır; önceki taramalar korunur:

```text
Kitabım_20261007_153000_ab12cd/
  kitap.pdf
  kitap.docx
  tarama.json
  sayfalar/
    sayfa_00001.png
    sayfa_00002.png
```

Sayfa değişmiyorsa veya daha önce yakalanan aynı sayfa tekrar geliyorsa tarama durur. Bu, kitap sonu veya düğme/odak sorunu olabilir; program kitap sonunu kesin olarak ayırt edemez. Kasıtlı olarak aynı görünen ardışık sayfalarda da durabilir. Sayfa sabitlenmiyorsa bekleme süresini artırın. Önce 3–5 sayfalık bir deneme yapın.

## Word ve OCR

- **Görüntülü Word:** Her sayfa bir resimdir. Görünüm korunur; metin düzenlenebilir değildir. Ek yazılım gerektirmez.
- **Düzenlenebilir Word:** Yerel **Tesseract OCR** kullanılır. Metin çıkarılır; sayfa düzeninin birebir korunması beklenmez. Çıktının imlasını, satırlarını ve özellikle tablolarını kontrol edin.
- PDF, ekran görüntülerinden oluşur; bu sürümde aranabilir OCR metin katmanı eklenmez.

Düzenlenebilir Word için Tesseract'ın Windows sürümünü kurun. Tesseract projesinin [Windows kurulum yönlendirmesi](https://tesseract-ocr.github.io/tessdoc/Installation.html) üzerinden uygun dağıtımı seçin. Kurulumda **Turkish / Türkçe (`tur`)** ve gerekiyorsa **English (`eng`)** dil verilerini seçin. Uygulama PATH, `Program Files\Tesseract-OCR` ve yerel kullanıcı kurulumlarını kontrol eder. Bulamazsa **Tesseract yolu** alanına `tesseract.exe` dosyasının tam yolunu girin. Bu programda Tesseract motoru paketlenmemiştir.

Ekran yakalamanın kalitesi ekranda görülen sayfaya bağlıdır. Bölünmüş bir sayfa yerine her tıklamada tam bir sayfa gösteren görünüm kullanın. Yakalama işlemi engellenmiş veya siyah görüntü üreten bir okuyucuda program bu kısıtlamayı kaldırmaz.

## Kaynak koddan çalıştırma

Kaynak paketinde Python 3.12–3.14 (64 bit) gerekir. **Baslat.bat** ilk çalıştırmada `.venv` oluşturup bağımlılıkları PyPI'den indirir; sonraki çalıştırmalarda tekrar kurmaz. Manuel kurulum:

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe baslat.py
```

Uygulama yönetici yetkisi istemez. Okuyucuyu da normal kullanıcı olarak çalıştırın; Windows, daha yüksek yetkili pencerelere tuş/tıklama gönderimini engelleyebilir. Birden fazla monitörde kitabı ve seçilecek düğmeyi ana ekrana taşıyın. Ekran çözünürlüğü/ölçeği değişirse seçimleri yenileyin.

## Geliştirme ve doğrulama

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt -r requirements-dev.txt
QT_QPA_PLATFORM=offscreen .venv/bin/python -m pytest -q
```

Testler sayfa sırasını, bekleme/sabitlenmeyi, tekrarları, durdurmayı, kısmi kayıtları, PDF sayfa sayısını, Word resimlerini, OCR metnini ve Qt iş parçacığı köprüsünü denetler. Linux ortamında Windows tıklamaları testte benzetilir. Yerel Windows ekran yakalama/tıklama ve paket başlatma bu ortamda çalıştırılamamıştır; kullanıcı bilgisayarında 3–5 sayfalık deneme ile doğrulanmalıdır. Türkçe OCR kontrolü için `tur.traineddata`, İngilizce için `eng.traineddata` gerekir; bulunmayan OCR testleri açıkça atlanır.

`tools/build_portable.py`, resmi Python NuGet paketinin SHA-512 özetini ve Windows bağımlılıklarının PyPI SHA-256 / wheel RECORD özetlerini doğrulayarak taşınabilir paketi üretir. Kaynak paket ve Windows paketi `dist/` klasörüne yazılır. Üçüncü taraf lisanslar runtime ve paketlerin `.dist-info` klasörlerinde korunur.

Paketi yeniden üretmek için boş bir `build/KitapTarayici` konumuyla başlayın:

```bash
.venv/bin/python -m pip download --only-binary=:all: --platform win_amd64 --python-version 314 --implementation cp --abi cp314 --dest build/wheels -r requirements.txt
.venv/bin/python tools/build_portable.py --wheels build/wheels
```
