from kitap_tarayici.gui import main

if __name__ == "__main__":
    raise SystemExit(main())
