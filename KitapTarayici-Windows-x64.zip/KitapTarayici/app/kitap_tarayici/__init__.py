"""Yerel ekran yakalama ve kitap dışa aktarma uygulaması."""

__version__ = "1.0.0"
