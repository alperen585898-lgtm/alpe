from __future__ import annotations

import hashlib
import json
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from PIL import Image, ImageChops, ImageStat


class ScanCancelled(Exception):
    pass


class PageUnchanged(Exception):
    pass


def image_difference(first: Image.Image, second: Image.Image) -> float:
    """Full-resolution grayscale mean difference, normalized to 0..1."""
    if first.size != second.size:
        return 1.0
    difference = ImageChops.difference(first.convert("L"), second.convert("L"))
    return ImageStat.Stat(difference).mean[0] / 255.0


def safe_title(title: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", title).strip(" .")[:80]
    return cleaned or "Kitabım"


@dataclass
class ScanSettings:
    output_dir: Path
    title: str = "Kitabım"
    page_count: int = 100
    delay: float = 1.2
    countdown: int = 5
    word_mode: str = "images"
    ocr_language: str = "tur+eng"
    tesseract_path: str = ""
    region: tuple[int, int, int, int] | None = None


@dataclass
class ScanResult:
    directory: Path
    pages: list[Path] = field(default_factory=list)
    outputs: dict[str, Path] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    reason: str = ""


class ScanRunner:
    """Desktop-independent runner; all desktop operations are injected."""

    def __init__(self, settings: ScanSettings, capture: Callable[[], Image.Image],
                 advance: Callable[[], None], stop: threading.Event,
                 progress: Callable[[str, int], None] = lambda text, count: None,
                 *, wait: Callable[[float], bool] | None = None,
                 clock: Callable[[], float] = time.monotonic):
        self.settings = settings
        self.capture = capture
        self.advance = advance
        self.stop = stop
        self.progress = progress
        self.wait = wait or stop.wait
        self.clock = clock

    def pause(self, seconds: float):
        if self.stop.is_set() or self.wait(seconds):
            raise ScanCancelled

    def stable_page(self, previous: Image.Image | None) -> Image.Image:
        # Allow rendering to settle, then require two stable screenshots.
        self.pause(self.settings.delay)
        deadline = self.clock() + max(8.0, self.settings.delay * 3)
        candidate = None
        saw_change = previous is None
        while self.clock() < deadline:
            if self.stop.is_set():
                raise ScanCancelled
            current = self.capture().convert("RGB")
            changed = previous is None or image_difference(previous, current) > 0.0005
            saw_change = saw_change or changed
            if changed and candidate is not None and image_difference(candidate, current) <= 0.0005:
                return current
            candidate = current
            self.pause(0.35)
        if not saw_change:
            raise PageUnchanged
        raise RuntimeError("Sayfa görüntüsü sabitlenmedi. Bekleme süresini artırıp yeniden deneyin.")

    def run(self) -> ScanResult:
        cfg = self.settings
        if not 1 <= cfg.page_count <= 10000 or not 0.1 <= cfg.delay <= 30:
            raise ValueError("Sayfa sayısı veya bekleme süresi geçersiz.")
        name = f"{safe_title(cfg.title)}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}"
        directory = cfg.output_dir / name
        directory.mkdir(parents=True, exist_ok=False)
        pages_dir = directory / "sayfalar"
        pages_dir.mkdir()
        result = ScanResult(directory)
        hashes: set[str] = set()
        previous = None
        try:
            for remaining in range(cfg.countdown, 0, -1):
                self.progress(f"{remaining} saniye: e-kitap penceresini öne getirin. Esc ile durdurun.", 0)
                self.pause(1)
            for index in range(cfg.page_count):
                self.progress(f"Sayfa {index + 1} bekleniyor…", len(result.pages))
                page = self.stable_page(previous)
                digest = hashlib.sha256(page.tobytes()).hexdigest()
                if digest in hashes:
                    result.reason = "Daha önce yakalanan sayfa tekrar geldi; tarama durduruldu."
                    break
                if self.stop.is_set():
                    raise ScanCancelled
                path = pages_dir / f"sayfa_{index + 1:05d}.png"
                page.save(path, "PNG")
                hashes.add(digest)
                result.pages.append(path)
                self.write_manifest(result)
                self.progress(f"{index + 1} sayfa kaydedildi.", index + 1)
                previous = page
                if index + 1 < cfg.page_count:
                    if self.stop.is_set():
                        raise ScanCancelled
                    self.advance()
            else:
                result.reason = "İstenen sayfa sayısına ulaşıldı."
        except ScanCancelled:
            result.reason = "Tarama durduruldu; yakalanan sayfalar korundu."
        except PageUnchanged:
            result.reason = "Sayfa değişmedi: kitap sonu veya tıklama/odak sorunu. Yakalanan sayfalar korundu."
        except Exception as exc:
            result.reason = "Tarama sırasında hata oluştu; yakalanan sayfalar korundu."
            result.errors.append(str(exc))
        self.write_manifest(result)
        return result

    def write_manifest(self, result: ScanResult):
        data = {"title": self.settings.title, "region_pixels": self.settings.region,
                "requested_pages": self.settings.page_count,
                "captured_pages": len(result.pages),
                "pages": [str(p.relative_to(result.directory)) for p in result.pages],
                "reason": result.reason, "errors": result.errors,
                "outputs": {k: p.name for k, p in result.outputs.items()}}
        temporary = result.directory / "tarama.json.tmp"
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(result.directory / "tarama.json")
