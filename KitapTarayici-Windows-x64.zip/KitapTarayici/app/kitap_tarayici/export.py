from __future__ import annotations

import shutil
import threading
from pathlib import Path
from typing import Callable

from PIL import Image
from docx import Document
from docx.shared import Inches, Pt
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def export_pdf(pages: list[Path], target: Path, title: str):
    if not pages:
        raise ValueError("PDF için en az bir sayfa gerekiyor.")
    temporary = target.with_suffix(".pdf.tmp")
    try:
        pdf = canvas.Canvas(str(temporary), pagesize=A4, pageCompression=1)
        pdf.setTitle(title)
        pdf.setCreator("Kitap Tarayıcı")
        width, height = A4
        for path in pages:
            with Image.open(path) as image:
                scale = min(width / image.width, height / image.height)
                w, h = image.width * scale, image.height * scale
            pdf.drawImage(str(path), (width - w) / 2, (height - h) / 2, w, h)
            pdf.showPage()
        pdf.save()
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)


def find_tesseract(explicit: str = "") -> str | None:
    if explicit:
        return explicit if Path(explicit).is_file() else None
    found = shutil.which("tesseract")
    if found:
        return found
    import os
    for env_name in ("ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(env_name)
        if base:
            candidates = [Path(base) / "Tesseract-OCR" / "tesseract.exe",
                          Path(base) / "Programs" / "Tesseract-OCR" / "tesseract.exe"]
            for path in candidates:
                if path.is_file():
                    return str(path)
    return None


def prepare_ocr(command: str, language: str):
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = command
    available = set(pytesseract.get_languages(config=""))
    required = set(language.split("+"))
    if not required <= available:
        missing = ", ".join(sorted(required - available))
        raise RuntimeError(f"Tesseract dil verisi eksik: {missing}. Tesseract kurulumuna bu dilleri ekleyin.")
    return pytesseract


def export_word(pages: list[Path], target: Path, *, mode: str = "images",
                language: str = "tur+eng", tesseract_path: str = "",
                stop: threading.Event | None = None,
                progress: Callable[[str, int], None] = lambda text, count: None):
    if not pages or mode not in ("images", "text"):
        raise ValueError("Word çıktı ayarları geçersiz.")
    ocr = None
    if mode == "text":
        command = find_tesseract(tesseract_path)
        if not command:
            raise RuntimeError("Düzenlenebilir Word için Tesseract OCR gerekiyor. PDF ve sayfa görüntüleri saklandı.")
        ocr = prepare_ocr(command, language)
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.27), Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(0.5)
    section.left_margin = section.right_margin = Inches(0.5)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.line_spacing = 1
    empty_pages = []
    for index, path in enumerate(pages):
        if stop and stop.is_set():
            raise InterruptedError("Word dışa aktarma durduruldu. PDF ve sayfa görüntüleri saklandı.")
        progress(f"Word: {index + 1}/{len(pages)} sayfa işleniyor…", len(pages))
        if index:
            doc.add_page_break()
        if mode == "images":
            with Image.open(path) as image:
                # Reserve space for Word's mandatory trailing paragraph.
                scale = min(7.27 / image.width, 10.2 / image.height)
                doc.add_picture(str(path), width=Inches(image.width * scale),
                                height=Inches(image.height * scale))
        else:
            with Image.open(path) as image:
                text = ocr.image_to_string(image, lang=language, config="--psm 3", timeout=90)
            # XML 1.0 cannot carry these OCR control characters.
            text = "".join(c for c in text if ord(c) >= 32 or c in "\n\t\r")
            if not text.strip():
                empty_pages.append(index + 1)
                doc.add_paragraph("[Bu sayfada OCR metin bulamadı. Kaynak PNG görüntüsünü kontrol edin.]")
            else:
                for paragraph in text.strip().split("\n\n"):
                    doc.add_paragraph(paragraph.strip())
    temporary = target.with_suffix(".docx.tmp")
    try:
        doc.save(temporary)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    return empty_pages
