from __future__ import annotations

import sys
import threading
from pathlib import Path

from PIL import Image
from PySide6.QtCore import QPoint, QRect, Qt, QThread, QTimer, Signal, QUrl, QStandardPaths
from PySide6.QtGui import QColor, QCursor, QDesktopServices, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QScrollArea, QSpinBox, QVBoxLayout, QWidget,
)

from .core import ScanResult, ScanRunner, ScanSettings
from .export import export_pdf, export_word, find_tesseract, prepare_ocr
from .windows_input import WindowsInput


def pixmap_image(pixmap: QPixmap) -> Image.Image:
    image = pixmap.toImage().convertToFormat(QImage.Format.Format_RGBA8888)
    return Image.frombytes("RGBA", (image.width(), image.height()), bytes(image.bits()),
                           "raw", "RGBA", image.bytesPerLine()).convert("RGB")


class SelectionOverlay(QWidget):
    selected = Signal(object)

    def __init__(self, screenshot: QPixmap, mode: str):
        super().__init__()
        self.screenshot = screenshot
        self.mode = mode
        self.origin = None
        self.current = None
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setGeometry(QApplication.primaryScreen().geometry())
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setMouseTracking(True)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawPixmap(self.rect(), self.screenshot)
        painter.fillRect(self.rect(), QColor(4, 12, 28, 120))
        if self.origin is not None and self.current is not None:
            rectangle = QRect(self.origin, self.current).normalized()
            painter.save()
            painter.setClipRect(rectangle)
            painter.drawPixmap(self.rect(), self.screenshot)
            painter.restore()
            painter.setPen(QPen(QColor("#39d4c1"), 2))
            painter.drawRect(rectangle)
        painter.fillRect(12, 12, self.width() - 24, 58, QColor("#122139"))
        painter.setPen(QColor("#ffffff"))
        instruction = ("Kitabın yalnızca sayfa alanını sürükleyerek seçin" if self.mode == "region"
                       else "Sonraki sayfa düğmesinin ortasına bir kez tıklayın")
        painter.drawText(QRect(28, 18, self.width() - 56, 46), Qt.AlignmentFlag.AlignVCenter,
                         instruction + "   •   Esc: iptal")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.origin = event.position().toPoint()
            self.current = self.origin
            self.update()

    def mouseMoveEvent(self, event):
        if self.origin is not None:
            self.current = event.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton or self.origin is None:
            return
        point = event.position().toPoint()
        if self.mode == "point":
            self.selected.emit(self.mapToGlobal(point))
            self.close()
            return
        rect = QRect(self.origin, point).normalized().intersected(self.rect())
        if rect.width() < 40 or rect.height() < 40:
            self.origin = None
            self.update()
            return
        sx, sy = self.screenshot.width() / self.width(), self.screenshot.height() / self.height()
        box = (round(rect.left() * sx), round(rect.top() * sy),
               round((rect.left() + rect.width()) * sx), round((rect.top() + rect.height()) * sy))
        self.selected.emit(box)
        self.close()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.selected.emit(None)
            self.close()


class ScanWorker(QThread):
    progress = Signal(str, int)
    desktop_request = Signal(object)
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, settings: ScanSettings, navigation: str, point: QPoint | None):
        super().__init__()
        self.settings = settings
        self.navigation = navigation
        self.point = point
        self.scan_stop = threading.Event()
        self.export_stop = threading.Event()
        self.exporting = False

    def request(self, kind):
        request = {"kind": kind, "ready": threading.Event(), "result": None, "error": None}
        self.desktop_request.emit(request)
        if not request["ready"].wait(15):
            raise RuntimeError("Ekran yakalama yanıt vermedi.")
        if request["error"]:
            raise RuntimeError(request["error"])
        return request["result"]

    def stop(self):
        if self.exporting:
            self.export_stop.set()
        else:
            self.scan_stop.set()

    def run(self):
        monitoring_done = threading.Event()
        monitor = None
        try:
            controls = WindowsInput()

            def monitor_escape():
                was_pressed = False
                while not monitoring_done.wait(0.03):
                    pressed = controls.escape_pressed()
                    if pressed and not was_pressed:
                        self.stop()
                    was_pressed = pressed

            monitor = threading.Thread(target=monitor_escape, daemon=True)
            monitor.start()

            def advance():
                if self.scan_stop.is_set():
                    return
                if self.navigation == "click":
                    # Qt maps logical screen coordinates correctly at Windows DPI scales.
                    self.request("pointer")
                    if not self.scan_stop.is_set():
                        controls.click()
                else:
                    controls.key(self.navigation)

            runner = ScanRunner(self.settings, lambda: self.request("capture"), advance,
                                self.scan_stop, self.progress.emit)
            result = runner.run()
            self.exporting = True
            if result.pages:
                self.progress.emit("PDF hazırlanıyor; yakalanan sayfalar saklandı…", len(result.pages))
                try:
                    target = result.directory / "kitap.pdf"
                    export_pdf(result.pages, target, self.settings.title)
                    result.outputs["PDF"] = target
                except Exception as exc:
                    result.errors.append(f"PDF: {exc}")
                if self.settings.word_mode != "none":
                    try:
                        target = result.directory / "kitap.docx"
                        empty_pages = export_word(result.pages, target, mode=self.settings.word_mode,
                                                  language=self.settings.ocr_language,
                                                  tesseract_path=self.settings.tesseract_path,
                                                  stop=self.export_stop, progress=self.progress.emit)
                        result.outputs["Word"] = target
                        if empty_pages:
                            result.errors.append("OCR metin bulamadığı sayfalar: " + ", ".join(map(str, empty_pages)))
                    except Exception as exc:
                        result.errors.append(f"Word: {exc}")
                runner.write_manifest(result)
            self.completed.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            monitoring_done.set()
            if monitor:
                monitor.join(timeout=1)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.region = None
        self.point = None
        self.overlay = None
        self.worker = None
        self.result_dir = None
        self.screen_size = None
        self.screen_geometry = None
        self.setWindowTitle("Kitap Tarayıcı")
        available = QApplication.primaryScreen().availableGeometry()
        self.resize(min(890, available.width() - 40), min(760, available.height() - 80))
        container = QWidget()
        self.setCentralWidget(container)
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        container_layout.addWidget(scroll, 1)
        root = QWidget()
        scroll.setWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(15)
        title = QLabel("Kitap Tarayıcı")
        title.setObjectName("title")
        layout.addWidget(title)
        layout.addWidget(QLabel("Ekrandaki kitabınızı sayfa sayfa yakalayın. PDF ve Word olarak saklayın."))
        note = QLabel("ANA EKRAN  •  Tüm işlemler yerel  •  Tarama sırasında Esc ile durdurun")
        note.setObjectName("note")
        layout.addWidget(note)
        columns = QHBoxLayout()
        layout.addLayout(columns, 1)
        left, left_layout = self.card()
        right, right_layout = self.card()
        columns.addWidget(left, 1)
        columns.addWidget(right, 1)
        left_layout.addWidget(self.heading("1  ·  Sayfa ve geçiş alanı"))
        self.region_label = QLabel("Henüz sayfa alanı seçilmedi.")
        left_layout.addWidget(self.region_label)
        self.region_button = QPushButton("Sayfa alanını seç")
        self.region_button.clicked.connect(lambda: self.select("region"))
        left_layout.addWidget(self.region_button)
        self.preview = QLabel("Sayfa önizlemesi")
        self.preview.setObjectName("preview")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(170)
        self.preview.setMaximumHeight(220)
        left_layout.addWidget(self.preview, 1)
        self.navigation = QComboBox()
        self.navigation.addItem("Sonraki sayfa düğmesine tıkla", "click")
        self.navigation.addItem("Sağ ok tuşu", "right")
        self.navigation.addItem("Page Down tuşu", "pagedown")
        self.navigation.currentIndexChanged.connect(self.navigation_changed)
        left_layout.addWidget(self.navigation)
        self.point_button = QPushButton("Sonraki sayfa düğmesini seç")
        self.point_button.clicked.connect(lambda: self.select("point"))
        left_layout.addWidget(self.point_button)
        self.point_label = QLabel("Düğme konumu seçilmedi.")
        left_layout.addWidget(self.point_label)
        right_layout.addWidget(self.heading("2  ·  Tarama ve çıktı"))
        form = QFormLayout()
        form.setSpacing(12)
        right_layout.addLayout(form)
        self.title_input = QLineEdit("Kitabım")
        form.addRow("Kitap adı", self.title_input)
        self.pages = QSpinBox()
        self.pages.setRange(1, 10000)
        self.pages.setValue(100)
        form.addRow("En fazla sayfa", self.pages)
        self.delay = QDoubleSpinBox()
        self.delay.setRange(0.1, 30)
        self.delay.setSingleStep(0.2)
        self.delay.setValue(1.2)
        self.delay.setSuffix(" sn")
        form.addRow("Sayfa beklemesi", self.delay)
        self.countdown = QSpinBox()
        self.countdown.setRange(3, 30)
        self.countdown.setValue(5)
        self.countdown.setSuffix(" sn")
        form.addRow("Başlangıç süresi", self.countdown)
        self.word = QComboBox()
        self.word.addItem("PDF + görüntülü Word", "images")
        self.word.addItem("PDF + düzenlenebilir Word (OCR)", "text")
        self.word.addItem("Yalnızca PDF", "none")
        self.word.currentIndexChanged.connect(self.word_changed)
        form.addRow("Çıktı türü", self.word)
        self.language = QComboBox()
        self.language.addItem("Türkçe + İngilizce", "tur+eng")
        self.language.addItem("Türkçe", "tur")
        self.language.addItem("İngilizce", "eng")
        form.addRow("OCR dili", self.language)
        self.tesseract = QLineEdit()
        self.tesseract.setPlaceholderText("Otomatik bulunur; gerekirse tesseract.exe yolu")
        form.addRow("Tesseract yolu", self.tesseract)
        self.ocr_note = QLabel("Görüntülü Word sayfaları resim olarak içerir. OCR metni düzenlenebilir; biçim ve metin kontrolü gerekebilir.")
        self.ocr_note.setWordWrap(True)
        right_layout.addWidget(self.ocr_note)
        right_layout.addWidget(QLabel("Çıktı klasörü"))
        output_row = QHBoxLayout()
        self.output = QLineEdit(str(Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)) / "KitapTaramalari"))
        output_row.addWidget(self.output, 1)
        self.folder_button = QPushButton("Seç…")
        self.folder_button.clicked.connect(self.select_folder)
        output_row.addWidget(self.folder_button)
        right_layout.addLayout(output_row)
        right_layout.addStretch()
        tip = QLabel("Kitabı ana ekrana taşıyın. Sayfa alanına araç çubuklarını almayın. İlk sayfayı açın; tarama sırasında fareyi ve klavyeyi kullanmayın.")
        tip.setWordWrap(True)
        layout.addWidget(tip)
        self.status = QLabel("Hazır. Önce sayfa alanını ve geçiş düğmesini seçin.")
        self.status.setWordWrap(True)
        self.status.setObjectName("status")
        footer = QWidget()
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(28, 0, 28, 20)
        footer_layout.setSpacing(12)
        footer_layout.addWidget(self.status)
        container_layout.addWidget(footer)
        actions = QHBoxLayout()
        self.open_button = QPushButton("Çıktı klasörünü aç")
        self.open_button.setEnabled(False)
        self.open_button.clicked.connect(self.open_result)
        actions.addWidget(self.open_button)
        actions.addStretch()
        self.stop_button = QPushButton("Durdur · Esc")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_scan)
        actions.addWidget(self.stop_button)
        self.start_button = QPushButton("Taramayı başlat")
        self.start_button.setObjectName("primary")
        self.start_button.clicked.connect(self.start_scan)
        actions.addWidget(self.start_button)
        footer_layout.addLayout(actions)
        self.editable = [self.region_button, self.navigation, self.point_button, self.title_input,
                         self.pages, self.delay, self.countdown, self.word, self.language,
                         self.tesseract, self.output, self.folder_button]
        self.word_changed()

    @staticmethod
    def card():
        frame = QFrame()
        frame.setObjectName("card")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)
        return frame, layout

    @staticmethod
    def heading(text):
        label = QLabel(text)
        label.setObjectName("heading")
        return label

    def word_changed(self):
        enabled = self.word.currentData() == "text"
        self.language.setEnabled(enabled)
        self.tesseract.setEnabled(enabled)

    def navigation_changed(self):
        self.point_button.setEnabled(self.navigation.currentData() == "click")

    def select_folder(self):
        chosen = QFileDialog.getExistingDirectory(self, "Çıktı klasörü seç", self.output.text())
        if chosen:
            self.output.setText(chosen)

    def select(self, mode):
        self.hide()

        def create_overlay():
            screen = QApplication.primaryScreen()
            shot = screen.grabWindow(0)
            if shot.isNull():
                self.showNormal()
                QMessageBox.warning(self, "Ekran yakalanamadı", "Ekran yakalama iznini ve oturumun açık olduğunu kontrol edin.")
                return
            self.overlay = SelectionOverlay(shot, mode)
            self.overlay.selected.connect(lambda value: self.selection_done(mode, value, shot))
            self.overlay.showFullScreen()
            self.overlay.activateWindow()
        QTimer.singleShot(500, create_overlay)

    def selection_done(self, mode, value, shot):
        if value is not None:
            new_size = (shot.width(), shot.height())
            new_geometry = QApplication.primaryScreen().geometry()
            if self.screen_size is not None and (self.screen_size != new_size or self.screen_geometry != new_geometry):
                self.region = None
                self.point = None
                self.region_label.setText("Ekran değişti; sayfa alanını yeniden seçin.")
                self.point_label.setText("Düğme konumunu yeniden seçin.")
                self.preview.clear()
            self.screen_size = (shot.width(), shot.height())
            self.screen_geometry = QApplication.primaryScreen().geometry()
            if mode == "region":
                self.region = value
                x, y, right, bottom = value
                self.region_label.setText(f"Seçilen alan: {right - x} × {bottom - y} piksel")
                self.preview.setPixmap(shot.copy(x, y, right - x, bottom - y).scaled(
                    340, 200, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            else:
                self.point = value
                self.point_label.setText(f"Düğme konumu: {value.x()}, {value.y()}")
        self.showNormal()
        self.activateWindow()

    def start_scan(self):
        if not self.region:
            QMessageBox.information(self, "Alan seçin", "Önce e-kitabın sayfa alanını seçin.")
            return
        if self.navigation.currentData() == "click" and self.point is None:
            QMessageBox.information(self, "Düğme seçin", "Sonraki sayfa düğmesinin konumunu seçin.")
            return
        if not self.output.text().strip():
            QMessageBox.information(self, "Klasör seçin", "Bir çıktı klasörü seçin.")
            return
        if self.word.currentData() == "text":
            command = find_tesseract(self.tesseract.text().strip())
            if not command:
                QMessageBox.warning(self, "Tesseract bulunamadı", "Tesseract OCR kurun veya tesseract.exe yolunu belirtin. Tesseract olmadan görüntülü Word ve PDF kullanılabilir.")
                return
            try:
                prepare_ocr(command, self.language.currentData())
            except Exception as exc:
                QMessageBox.warning(self, "OCR kullanılamıyor", str(exc))
                return
        cfg = ScanSettings(Path(self.output.text()).expanduser(), self.title_input.text().strip() or "Kitabım",
                           self.pages.value(), self.delay.value(), self.countdown.value(),
                           self.word.currentData(), self.language.currentData(),
                           self.tesseract.text().strip(), self.region)
        self.worker = ScanWorker(cfg, self.navigation.currentData(), self.point)
        self.worker.desktop_request.connect(self.desktop_operation)
        self.worker.progress.connect(self.update_progress)
        self.worker.completed.connect(self.scan_completed)
        self.worker.failed.connect(self.scan_failed)
        self.worker.finished.connect(self.worker_finished)
        for widget in self.editable:
            widget.setEnabled(False)
        self.start_button.setEnabled(False)
        self.open_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status.setText("Tarama başlıyor. E-kitabı öne getirin; Esc ile durdurabilirsiniz.")
        self.showMinimized()
        self.worker.start()

    def desktop_operation(self, request):
        try:
            screen = QApplication.primaryScreen()
            shot = screen.grabWindow(0) if request["kind"] == "capture" else None
            if screen.geometry() != self.screen_geometry or (shot and (shot.width(), shot.height()) != self.screen_size):
                raise RuntimeError("Ekran çözünürlüğü veya ölçek değişti. Alanı ve düğmeyi yeniden seçin.")
            if request["kind"] == "pointer":
                QCursor.setPos(self.point)
            else:
                if shot.isNull():
                    raise RuntimeError("Ekran görüntüsü alınamadı. Oturum kilitli olabilir.")
                request["result"] = pixmap_image(shot).crop(self.region)
        except Exception as exc:
            request["error"] = str(exc)
        finally:
            request["ready"].set()

    def update_progress(self, text, count):
        self.status.setText(text)
        self.setWindowTitle(f"Kitap Tarayıcı · {count} sayfa")

    def stop_scan(self):
        if self.worker:
            self.worker.stop()
            self.status.setText("Durduruluyor. Yakalanan sayfalar ve PDF korunacak…")

    def scan_completed(self, result: ScanResult):
        self.result_dir = result.directory
        outputs = ", ".join(result.outputs) or "çıktı üretilmedi"
        self.status.setText(f"{len(result.pages)} sayfa · {outputs}. {result.reason}")
        self.open_button.setEnabled(True)
        self.showNormal()
        self.activateWindow()
        if result.errors:
            QMessageBox.warning(self, "Tarama sonuçları", "\n".join(result.errors) + f"\n\nKayıt klasörü: {result.directory}")

    def scan_failed(self, message):
        self.showNormal()
        self.activateWindow()
        self.status.setText("Tarama başlatılamadı.")
        QMessageBox.warning(self, "Hata", message)

    def worker_finished(self):
        for widget in self.editable:
            widget.setEnabled(True)
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.word_changed()
        self.navigation_changed()

    def open_result(self):
        if self.result_dir:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.result_dir)))

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.stop_scan()
            self.showNormal()
            self.status.setText("Önce tarama ve dışa aktarma tamamlanacak. Ardından pencereyi kapatabilirsiniz.")
            event.ignore()
        else:
            event.accept()


STYLE = """
QWidget { background: #101a2c; color: #edf2fa; font-family: 'Segoe UI'; font-size: 13px; }
QLabel#title { font-size: 30px; font-weight: 700; }
QLabel#note { color: #74daca; font-size: 12px; }
QLabel#heading { font-size: 17px; font-weight: 600; }
QFrame#card { background: #17243a; border: 1px solid #2a3d58; border-radius: 12px; }
QFrame#card QLabel { background: transparent; }
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { background: #0f1b2e; border: 1px solid #3b506b; border-radius: 5px; padding: 7px; min-height: 18px; }
QPushButton { background: #243b58; border: 1px solid #395471; border-radius: 6px; padding: 10px 13px; }
QPushButton:hover { background: #315074; }
QPushButton:disabled { color: #74859c; background: #1a2940; }
QPushButton#primary { background: #28bca7; color: #072b28; font-weight: 700; border: 0; }
QPushButton#primary:hover { background: #55d7c2; }
QLabel#preview { background: #0a1322; border: 1px dashed #3b506b; border-radius: 6px; color: #94a8c2; }
QLabel#status { background: #192c43; padding: 12px; border-radius: 7px; color: #a6e5dc; }
QComboBox QAbstractItemView { background: #17243a; selection-background-color: #315074; }
"""


def main():
    if sys.platform == "win32":
        # Enable physical-coordinate input before Qt initializes.
        import ctypes
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except (AttributeError, OSError):
            pass
    app = QApplication(sys.argv)
    app.setApplicationName("Kitap Tarayıcı")
    app.setStyleSheet(STYLE)
    window = MainWindow()
    window.show()
    return app.exec()
