"""Windows input, using native APIs without background hook dependencies."""
import ctypes
import sys
from ctypes import wintypes


class WindowsInput:
    def __init__(self):
        if sys.platform != "win32":
            raise RuntimeError("Ekran taraması Windows 10/11 içindir. PDF/Word dönüştürme modülleri diğer sistemlerde de test edilebilir.")

        class MouseInput(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                        ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                        ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

        class KeyboardInput(ctypes.Structure):
            _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                        ("dwExtraInfo", ctypes.c_size_t)]

        class HardwareInput(ctypes.Structure):
            _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

        class InputUnion(ctypes.Union):
            _fields_ = [("mi", MouseInput), ("ki", KeyboardInput), ("hi", HardwareInput)]

        class Input(ctypes.Structure):
            _anonymous_ = ("data",)
            _fields_ = [("type", wintypes.DWORD), ("data", InputUnion)]

        self.Input = Input
        self.MouseInput = MouseInput
        self.KeyboardInput = KeyboardInput
        self.api = ctypes.WinDLL("user32", use_last_error=True)
        self.api.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int)
        self.api.SendInput.restype = wintypes.UINT
        self.api.GetAsyncKeyState.argtypes = (ctypes.c_int,)
        self.api.GetAsyncKeyState.restype = ctypes.c_short

    def send(self, inputs):
        array = (self.Input * len(inputs))(*inputs)
        if self.api.SendInput(len(inputs), array, ctypes.sizeof(self.Input)) != len(inputs):
            raise RuntimeError("Windows tıklama/tuş gönderimini engelledi. E-kitap okuyucusunu normal kullanıcı olarak çalıştırın.")

    def click(self):
        self.send([self.Input(type=0, mi=self.MouseInput(dwFlags=2)),
                   self.Input(type=0, mi=self.MouseInput(dwFlags=4))])

    def key(self, mode):
        code = 0x27 if mode == "right" else 0x22
        self.send([self.Input(type=1, ki=self.KeyboardInput(wVk=code)),
                   self.Input(type=1, ki=self.KeyboardInput(wVk=code, dwFlags=2))])

    def escape_pressed(self):
        return bool(self.api.GetAsyncKeyState(0x1B) & 0x8000)
